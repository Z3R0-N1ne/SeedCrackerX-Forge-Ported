package kaptainwutax.seedcrackerX.api;

public interface SeedCrackerAPI {
    void pushWorldSeed(long seed);
}
