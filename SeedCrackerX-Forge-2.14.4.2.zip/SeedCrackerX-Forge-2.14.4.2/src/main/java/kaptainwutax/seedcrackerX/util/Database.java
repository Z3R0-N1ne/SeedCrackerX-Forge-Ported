package kaptainwutax.seedcrackerX.util;

import com.mojang.authlib.HttpAuthenticationService;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.exceptions.InsufficientPrivilegesException;
import com.mojang.authlib.exceptions.InvalidCredentialsException;
import kaptainwutax.seedcrackerX.config.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;

public class Database {

    public static Component joinFakeServerForAuth() {
        try {
            Minecraft client = Minecraft.getInstance();
            client.getMinecraftSessionService().joinServer(client.getUser().getGameProfile(), client.getUser().getAccessToken(), "seedcrackerx");
        }
        catch (AuthenticationUnavailableException authenticationUnavailableException) {
            return Component.translatable("disconnect.loginFailedInfo", Component.translatable("disconnect.loginFailedInfo.serversUnavailable"));
        }
        catch (InvalidCredentialsException authenticationUnavailableException) {
            return Component.translatable("disconnect.loginFailedInfo", Component.translatable("disconnect.loginFailedInfo.invalidSession"));
        }
        catch (InsufficientPrivilegesException authenticationUnavailableException) {
            return Component.translatable("disconnect.loginFailedInfo", Component.translatable("disconnect.loginFailedInfo.insufficientPrivileges"));
        }
        catch (AuthenticationException authenticationUnavailableException) {
            return Component.translatable("disconnect.loginFailedInfo", authenticationUnavailableException.getMessage());
        }
        return null;
    }

    public static void handleDatabaseCall(Long seed) {
        HttpClient httpClient = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_2)
                .build();
        Minecraft client = Minecraft.getInstance();
        Map<String,Object> data = new HashMap<>();
        data.put("serverIp", client.getConnection().getConnection().getRemoteAddress().toString());
        data.put("dimension", client.level.dimensionType().effectsLocation().getPath());
        data.put("seed", seed+"L"); //javascript backend likes floating point. so we need to convert it to a string
        data.put("version", Config.get().getVersion().name);
        data.put("username", client.player.getName().getString());
        data.put("hash", Config.get().anonymusSubmits? 1 : 0);


        HttpRequest request = HttpRequest.newBuilder()
                .POST(HttpRequest.BodyPublishers.ofString(HttpAuthenticationService.buildQuery(data)))
                .uri(URI.create("https://script.google.com/macros/s/AKfycbzU-o8IUaKMQ-MOJEqD8hFGTAC7E15l4uiVqkQsOWxGXgh_HVny6x_TSDVKR8V2wmm9Aw/exec"))
                .setHeader("User-Agent", "SeedcrackerX mod")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 302) { //the page says "document moved" but the post gets processed
                Log.warn("database.success");
            } else {
                Log.warn("database.fail");
            }
        } catch (IOException | InterruptedException e) {
            Log.warn("database.fail");
        }
    }
}
